*****************************************************
 _____    _____              ____    _         ____  
|  __ \  |_   _|     /\     |  _ \  | |       / __ \ 
| |  | |   | |      /  \    | |_) | | |      | |  | |
| |  | |   | |     / /\ \   |  _ <  | |      | |  | |
| |__| |  _| |_   / ____ \  | |_) | | |____  | |__| |
|_____/  |_____| /_/    \_\ |____/  |______|  \____/ 
*****************************************************

Toto je jednoduchá textová hra na motivy počítačové hry Diablo 2: Lord of Destruction. Zpracoval jsem ji na základě semestrální práce do předmětu 4IT101 v jazyce Java v prostředí BlueJ.
Úkolem hráče je postupně projít všemi místnostmi, zabít monstra a plnit úkoly které dostává v táboru tuláků(základním místě hry). Výhra nastane po zabití Andariel v Katakombách a po uložení předmětu pohár vítězství do batohu.

*****************************************************

Autor: Michal Chobola
Verze 9.1.2017

*****************************************************

Hláška PMD:
	Třída: Prostor
	hláška: Mnoho vnořených příkazů if..then se špatně čte.
	řádek: 171
	vysvětlení: vnoření příkazu if je nutné kvůli výpisu čárky za prostorem

